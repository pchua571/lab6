import React from 'react';

const ErrorPage = () => {
    return (
        <div>
            <p>An error has occurred</p>
        </div>
    );
};

export default ErrorPage;
